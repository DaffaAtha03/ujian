// main.js - small helper (currently unused)
// Add JS if you want client-side enhancements (search, AJAX, etc.)
console.log('Main.js loaded');
